//
//  IDZTrace.h
//  IDZAudioPlayerDevelopment
//
//  Created by idz on 2/13/13.
//  Copyright (c) 2013 idz. All rights reserved.
//

#ifndef IDZAudioPlayerDevelopment_IDZTrace_h
#define IDZAudioPlayerDevelopment_IDZTrace_h

#define IDZTrace() NSLog(@"%s", __PRETTY_FUNCTION__)

#endif
