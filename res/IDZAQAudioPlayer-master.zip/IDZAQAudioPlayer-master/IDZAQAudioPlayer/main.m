//
//  main.m
//  IDZAQAudioPlayer
//
//  Created by idz on 4/5/13.
//  Copyright (c) 2013 iOSDeveloperZone.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "IDZAQAudioPlayerAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([IDZAQAudioPlayerAppDelegate class]));
    }
}
