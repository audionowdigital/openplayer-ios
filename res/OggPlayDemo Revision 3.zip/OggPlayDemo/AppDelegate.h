//
//  AppDelegate.h
//  OggPlayDemo
//
//  Created by Danila Shikulin on 16/4/12.
//  Copyright (c) 2012 COS. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
