# AVBufferPlayer

Simple class that uses `AVAudioPlayer` to play a buffer of waveform data that you give it. You can use this for simple non-realtime sound synthesis.
