//
//  IosAudioExampleViewController.h
//  IosAudioExample
//
//  Created by Pete Goodliffe on 17/11/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IosAudioExampleViewController : UIViewController
{
}

- (IBAction) pleaseMakeItStop:(id)sender;

@end

